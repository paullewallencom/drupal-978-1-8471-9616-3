// $Id$

/**
 * Verify that the autoloader is working.
 * @file
 */
 
jQuery(document).ready(function() {
  console.log("JS Loader is ready.");
});
